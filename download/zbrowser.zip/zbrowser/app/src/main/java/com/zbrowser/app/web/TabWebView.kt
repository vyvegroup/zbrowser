package com.zbrowser.app.web

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.os.Bundle
import android.view.KeyEvent
import android.webkit.*
import android.widget.FrameLayout

/**
 * Custom WebView that represents a single browser tab.
 * Each tab has its own WebView instance with independent state.
 */
@SuppressLint("SetJavaScriptEnabled")
class TabWebView(
    context: Context,
    val tabId: String,
    private val onPageStarted: (String) -> Unit = {},
    private val onPageFinished: (String) -> Unit = {},
    private val onProgressChanged: (Int) -> Unit = {},
    private val onTitleReceived: (String) -> Unit = {},
    private val onIconReceived: (Bitmap?) -> Unit = {},
    private val onRequestNewTab: (String) -> Unit = {},
    private val onDownloadRequested: (DownloadRequest) -> Unit = {}
) : WebView(context) {

    var currentUrl: String = "about:blank"
        private set
    var currentTitle: String = ""
        private set
    var currentFavicon: Bitmap? = null
        private set
    var isLoading: Boolean = false
        private set
    var progress: Int = 0
        private set
    var isDesktopMode: Boolean = false

    private val defaultUserAgent = settings.userAgentString

    init {
        layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        )

        setupSettings()
        setupWebViewClient()
        setupWebChromeClient()
        setupDownloadListener()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupSettings() {
        settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            loadWithOverviewMode = true
            useWideViewPort = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            setSupportMultipleWindows(true)
            javaScriptCanOpenWindowsAutomatically = true
            layoutAlgorithm = WebSettings.LayoutAlgorithm.TEXT_AUTOSIZING
        }

        // Enable WebView debugging in debug builds
        if (BuildConfig.DEBUG) {
            WebView.setWebContentsDebuggingEnabled(true)
        }
    }

    private fun setupWebViewClient() {
        webViewClient = object : WebViewClient() {

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url.toString()

                // Handle special URL schemes
                when {
                    url.startsWith("tel:") -> {
                        // Let the system handle phone numbers
                        return false
                    }
                    url.startsWith("mailto:") -> {
                        // Let the system handle email
                        return false
                    }
                    url.startsWith("intent:") -> {
                        // Handle intent URLs
                        return false
                    }
                }

                return false
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                isLoading = true
                url?.let {
                    currentUrl = it
                    onPageStarted(it)
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                isLoading = false
                url?.let {
                    currentUrl = it
                    onPageFinished(it)
                }
            }

            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                super.doUpdateVisitedHistory(view, url, isReload)
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                super.onReceivedError(view, request, error)
                if (request?.isForMainFrame == true) {
                    // Show error page for main frame errors
                }
            }

            override fun onReceivedHttpError(view: WebView?, request: WebResourceRequest?, errorResponse: WebResourceResponse?) {
                super.onReceivedHttpError(view, request, errorResponse)
            }

            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslErrorHandler?) {
                // Let the activity handle SSL errors
                super.onReceivedSslError(view, handler, error)
            }
        }
    }

    private fun setupWebChromeClient() {
        webChromeClient = object : WebChromeClient() {

            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                super.onProgressChanged(view, newProgress)
                progress = newProgress
                onProgressChanged(newProgress)
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                super.onReceivedTitle(view, title)
                title?.let {
                    currentTitle = it
                    onTitleReceived(it)
                }
            }

            override fun onReceivedIcon(view: WebView?, icon: Bitmap?) {
                super.onReceivedIcon(view, icon)
                currentFavicon = icon
                onIconReceived(icon)
            }

            override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?): Boolean {
                // Handle new window requests (target="_blank" links)
                val href = view?.hitTestResult?.extra
                if (href != null) {
                    onRequestNewTab(href)
                }
                return true
            }

            override fun onGeolocationPermissionsShowPrompt(origin: String?, callback: GeolocationPermissions.Callback?) {
                // Request location permission from the activity
                callback?.invoke(origin, true, false)
            }

            override fun onPermissionRequest(request: PermissionRequest?) {
                // Auto-grant common permissions
                request?.grant(request.resources)
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                // File chooser should be handled by the activity
                return false
            }
        }
    }

    private fun setupDownloadListener() {
        setDownloadListener { url, userAgent, contentDisposition, mimetype, contentLength ->
            onDownloadRequested(DownloadRequest(url, userAgent, contentDisposition, mimetype, contentLength))
        }
    }

    fun loadUrl(url: String) {
        val finalUrl = when {
            url.startsWith("http://") || url.startsWith("https://") -> url
            url.startsWith("about:blank") -> url
            url.contains(".") && !url.contains(" ") -> "https://$url"
            else -> {
                // Treat as search query
                "https://www.google.com/search?q=${java.net.URLEncoder.encode(url, "UTF-8")}"
            }
        }
        super.loadUrl(finalUrl)
    }

    fun search(query: String) {
        val searchUrl = "https://www.google.com/search?q=${java.net.URLEncoder.encode(query, "UTF-8")}"
        super.loadUrl(searchUrl)
    }

    fun toggleDesktopMode() {
        isDesktopMode = !isDesktopMode
        settings.apply {
            if (isDesktopMode) {
                userAgentString = defaultUserAgent.replace("Mobile", "eliboM").replace("Android", "diordnA")
                useWideViewPort = true
                loadWithOverviewMode = false
            } else {
                userAgentString = defaultUserAgent
                useWideViewPort = true
                loadWithOverviewMode = true
            }
        }
        reload()
    }

    fun canGoBackSafe(): Boolean = canGoBack()

    fun goBackSafe() {
        if (canGoBack()) goBack()
    }

    fun canGoForwardSafe(): Boolean = canGoForward()

    fun goForwardSafe() {
        if (canGoForward()) goForward()
    }

    fun saveState(outState: Bundle): WebBackForwardList? {
        return super.saveState(outState)
    }

    fun restoreStateSafe(inState: Bundle): WebBackForwardList? {
        return restoreState(inState)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && canGoBack()) {
            goBack()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    fun cleanup() {
        stopLoading()
        settings.javaScriptEnabled = false
        clearHistory()
        clearCache(true)
        loadUrl("about:blank")
    }

    data class DownloadRequest(
        val url: String,
        val userAgent: String,
        val contentDisposition: String,
        val mimetype: String,
        val contentLength: Long
    )
}
